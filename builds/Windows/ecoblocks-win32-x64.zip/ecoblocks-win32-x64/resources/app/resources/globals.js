var globalMapAgentsDeclared = {}; // This Dictionary maps all species created by the user
var globalSimulationSpeed = 0.7; // NetLogo simulation speed in seconds
var globalAgentsMovementCode = []; // This array maintains the code that keeps the agents moving accordingly